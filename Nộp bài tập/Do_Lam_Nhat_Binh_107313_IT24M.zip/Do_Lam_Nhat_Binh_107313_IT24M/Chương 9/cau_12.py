import numpy as np
from sklearn.datasets import load_digits
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split


def reconstruction_error(model, samples):
    reconstructed = model.inverse_transform(model.transform(samples))
    return np.mean((samples - reconstructed) ** 2, axis=1)


def main():
    digits = load_digits()
    x_train, x_test = train_test_split(
        digits.data,
        test_size=0.30,
        random_state=42,
        stratify=digits.target,
    )
    x_fit, x_calibration = train_test_split(
        x_train, test_size=0.25, random_state=42
    )

    # Fit PCA on ordinary training images; calibrate the cutoff on held-out
    # ordinary images so the cutoff is not based on in-sample errors.
    pca = PCA(n_components=0.95, svd_solver="full")
    pca.fit(x_fit)
    calibration_errors = reconstruction_error(pca, x_calibration)
    threshold = np.percentile(calibration_errors, 99)

    clean_errors = reconstruction_error(pca, x_test)
    rng = np.random.default_rng(42)
    corrupted = x_test.copy()
    n_corrupted_pixels = max(1, int(corrupted.shape[1] * 0.20))
    for row in corrupted:
        indices = rng.choice(
            corrupted.shape[1], size=n_corrupted_pixels, replace=False
        )
        row[indices] = rng.uniform(0.0, 16.0, size=n_corrupted_pixels)
    anomaly_errors = reconstruction_error(pca, corrupted)

    clean_false_positive_rate = np.mean(clean_errors > threshold)
    anomaly_detection_rate = np.mean(anomaly_errors > threshold)

    print(f"Original feature count: {x_fit.shape[1]}")
    print(f"PCA components retaining 95% variance: {pca.n_components_}")
    print(f"Reconstruction-error threshold (99th percentile): {threshold:.4f}")
    print(
        "Clean test images flagged: "
        f"{clean_false_positive_rate:.1%}"
    )
    print(
        "Artificially corrupted images detected: "
        f"{anomaly_detection_rate:.1%}"
    )
    print(
        "This example treats unusually large reconstruction error as an "
        "anomaly; the threshold and results depend on the data and corruption."
    )


if __name__ == "__main__":
    main()
