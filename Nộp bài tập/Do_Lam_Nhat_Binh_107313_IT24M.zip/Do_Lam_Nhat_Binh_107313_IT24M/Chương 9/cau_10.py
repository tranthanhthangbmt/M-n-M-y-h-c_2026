from sklearn.cluster import KMeans
from sklearn.datasets import load_digits
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import adjusted_rand_score, accuracy_score
from sklearn.model_selection import train_test_split


def main():
    digits = load_digits()
    x_train, x_test, y_train, y_test = train_test_split(
        digits.data,
        digits.target,
        test_size=0.25,
        random_state=42,
        stratify=digits.target,
    )

    # Each image becomes a vector of distances to the 50 learned centroids.
    kmeans = KMeans(n_clusters=50, n_init=10, random_state=42)
    kmeans.fit(x_train)
    x_train_reduced = kmeans.transform(x_train)
    x_test_reduced = kmeans.transform(x_test)

    full_model = LogisticRegression(max_iter=3000)
    full_model.fit(x_train, y_train)
    reduced_model = LogisticRegression(max_iter=3000)
    reduced_model.fit(x_train_reduced, y_train)

    full_accuracy = accuracy_score(y_test, full_model.predict(x_test))
    reduced_accuracy = accuracy_score(
        y_test, reduced_model.predict(x_test_reduced)
    )
    cluster_ari = adjusted_rand_score(y_train, kmeans.labels_)

    print(f"Original feature count: {x_train.shape[1]}")
    print(f"Reduced feature count: {x_train_reduced.shape[1]}")
    print(f"K-Means training inertia: {kmeans.inertia_:.2f}")
    print(f"Clustering adjusted Rand index: {cluster_ari:.4f}")
    print(f"Classifier accuracy on original features: {full_accuracy:.4f}")
    print(f"Classifier accuracy on reduced features: {reduced_accuracy:.4f}")
    print(
        "The reduced representation may be less accurate, but uses fewer "
        "features; the measured results depend on the train/test split."
    )


if __name__ == "__main__":
    main()
